import React from 'react';

const ThemeContext = React.createContext(null);

export default ThemeContext;