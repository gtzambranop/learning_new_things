export const CARGANDO = 'publicaciones_cargando';
export const ERROR = 'publicaciones_error';
export const ACTUALIZAR = 'publicaciones_actualizar';
export const COM_CARGANDO = 'comentarios_cargando';
export const COM_ERROR = 'comentarios_error';
export const COM_ACTUALIZAR = 'comentarios_actualizar';