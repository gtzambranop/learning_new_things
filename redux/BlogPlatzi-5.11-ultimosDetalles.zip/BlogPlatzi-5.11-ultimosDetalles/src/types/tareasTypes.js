export const TRAER_TODAS = 'tareas_traer_todas';
export const CARGANDO = 'tareas_cargando';
export const ERROR = 'tareas_error';
export const CAMBIO_USUARIO = 'tareas_cambio_usuario_id';
export const CAMBIO_TITULO = 'tareas_cambio_titulo';
export const GUARDADA = 'tareas_guardada';
export const ACTUALIZAR = 'tareas_actualizar';
export const LIMPIAR = 'tareas_limpiar';